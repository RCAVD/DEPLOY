﻿Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows" -Name "LegacyDefaultPrinterMode" -Value 1 -Force

Add-Printer -ConnectionName "\\PRS01\HP500-DN"

#Makes default printer
$var = New-Object -COM WScript.Network 
$var.setdefaultprinter("\\PRS01\HP500-DN")