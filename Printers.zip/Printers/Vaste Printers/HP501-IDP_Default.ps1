﻿Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows" -Name "LegacyDefaultPrinterMode" -Value 1 -Force

Add-Printer -ConnectionName "\\prs01\HP501-IDP"

#Makes default printer
$var = New-Object -COM WScript.Network 
$var.setdefaultprinter("\\prs01\HP501-IDP")