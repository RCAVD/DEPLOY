﻿Push-Location C:\Custom

.\DelProf2.exe /u