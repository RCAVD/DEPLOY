﻿#The solution to the problem is to clean the registry and to do this you need to use PSExec, downloadable from the Microsoft site, and do it by launching a PowerShell console such as SYSTEM – Psexec.exe -I -s powershell.exe

Stop-Service spooler

Remove-Item -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Print\Providers\Client Side Rendering Print Provider*" -Recurse
Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Print\Printers*" -Recurse

Remove-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Enum\SWD\PRINTENUM*" -Recurse
Remove-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\DeviceClasses\{0ecef634-6ef0-472a-8085-5ad023ecbccd}*" -Recurse

Start-Service spooler